"""Entry point for budget-analyst module."""


if __name__ == "__main__":
    pass  # MCP Mesh handles startup via @mesh.agent
