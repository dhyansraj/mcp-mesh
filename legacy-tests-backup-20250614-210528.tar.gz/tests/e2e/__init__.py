"""End-to-end tests for MCP Mesh SDK."""
