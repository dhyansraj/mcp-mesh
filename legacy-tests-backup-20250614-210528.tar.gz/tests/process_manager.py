#!/usr/bin/env python3
"""
Process manager for integration tests.
Handles process groups for clean shutdown.
"""

import logging
import os
import signal
import subprocess
import time

logger = logging.getLogger(__name__)


class TestProcessManager:
    """Manages test processes with proper process group handling."""

    def __init__(self):
        self.processes: dict[str, subprocess.Popen] = {}
        self.process_groups: dict[str, int] = {}

    def start_process(
        self,
        name: str,
        cmd: list[str],
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> subprocess.Popen:
        """Start a process in its own process group."""
        logger.info(f"Starting process '{name}': {' '.join(cmd)}")

        # Merge environment
        final_env = os.environ.copy()
        if env:
            final_env.update(env)

        # Start process in new process group
        proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            env=final_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid,  # Create new process group
            text=True,
            bufsize=1,  # Line buffered
        )

        self.processes[name] = proc
        self.process_groups[name] = proc.pid  # Process group ID = process ID

        logger.info(
            f"Started process '{name}' with PID {proc.pid} in process group {proc.pid}"
        )
        return proc

    def wait_for_startup(
        self, name: str, timeout: float = 30.0, check_interval: float = 0.5
    ) -> bool:
        """Wait for a process to start successfully."""
        if name not in self.processes:
            return False

        proc = self.processes[name]
        start_time = time.time()

        while time.time() - start_time < timeout:
            if proc.poll() is not None:
                # Process has exited
                logger.error(
                    f"Process '{name}' exited during startup with code {proc.returncode}"
                )
                return False

            time.sleep(check_interval)

            # Check if process is responding (could add health checks here)
            # For now, just assume it's ready if it hasn't crashed
            if time.time() - start_time > 2.0:  # Give it at least 2 seconds
                logger.info(f"Process '{name}' appears to be running")
                return True

        logger.error(f"Process '{name}' startup timeout after {timeout}s")
        return False

    def stop_process(self, name: str, timeout: float = 10.0) -> bool:
        """Stop a process gracefully, then forcefully if needed."""
        if name not in self.processes:
            logger.warning(f"Process '{name}' not found")
            return True

        proc = self.processes[name]
        pgid = self.process_groups[name]

        if proc.poll() is not None:
            logger.info(f"Process '{name}' already exited with code {proc.returncode}")
            self._cleanup_process(name)
            return True

        logger.info(f"Stopping process group for '{name}' (PGID: {pgid})")

        try:
            # Send SIGTERM to the entire process group
            os.killpg(pgid, signal.SIGTERM)

            # Wait for graceful shutdown
            try:
                proc.wait(timeout=timeout)
                logger.info(f"Process '{name}' shut down gracefully")
                self._cleanup_process(name)
                return True
            except subprocess.TimeoutExpired:
                logger.warning(
                    f"Process '{name}' did not shut down gracefully, force killing"
                )

                # Force kill the process group
                os.killpg(pgid, signal.SIGKILL)
                proc.wait(timeout=5.0)  # Should be immediate
                logger.info(f"Process '{name}' force killed")
                self._cleanup_process(name)
                return True

        except ProcessLookupError:
            # Process group doesn't exist (already dead)
            logger.info(f"Process group for '{name}' already gone")
            self._cleanup_process(name)
            return True
        except Exception as e:
            logger.error(f"Error stopping process '{name}': {e}")
            self._cleanup_process(name)
            return False

    def stop_all(self, timeout: float = 10.0) -> bool:
        """Stop all managed processes."""
        logger.info("Stopping all test processes...")

        success = True
        for name in list(self.processes.keys()):
            if not self.stop_process(name, timeout):
                success = False

        return success

    def get_process_output(self, name: str) -> tuple[str | None, str | None]:
        """Get stdout and stderr from a process."""
        if name not in self.processes:
            return None, None

        proc = self.processes[name]
        try:
            stdout, stderr = proc.communicate(timeout=1.0)
            return stdout, stderr
        except subprocess.TimeoutExpired:
            # Process still running
            return None, None

    def is_running(self, name: str) -> bool:
        """Check if a process is still running."""
        if name not in self.processes:
            return False

        proc = self.processes[name]
        return proc.poll() is None

    def _cleanup_process(self, name: str):
        """Clean up process tracking."""
        if name in self.processes:
            del self.processes[name]
        if name in self.process_groups:
            del self.process_groups[name]

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop_all()


# Convenience functions for test scripts
def start_registry(port: int = 8000, timeout: float = 30.0) -> TestProcessManager:
    """Start the registry and return a process manager."""
    pm = TestProcessManager()

    pm.start_process(
        "registry", ["make", "start-registry"], env={"REGISTRY_PORT": str(port)}
    )

    if not pm.wait_for_startup("registry", timeout):
        pm.stop_all()
        raise RuntimeError("Failed to start registry")

    return pm


def start_python_agent(
    script_path: str, working_dir: str = ".", timeout: float = 30.0
) -> TestProcessManager:
    """Start a Python agent and return a process manager."""
    pm = TestProcessManager()

    pm.start_process("agent", ["python", script_path], cwd=working_dir)

    if not pm.wait_for_startup("agent", timeout):
        pm.stop_all()
        raise RuntimeError(f"Failed to start agent: {script_path}")

    return pm


if __name__ == "__main__":
    # Test the process manager
    logging.basicConfig(level=logging.INFO)

    with TestProcessManager() as pm:
        # Test starting a simple process
        pm.start_process("test", ["sleep", "5"])
        print(f"Process running: {pm.is_running('test')}")
        time.sleep(2)
        print(f"Process still running: {pm.is_running('test')}")
        print("Stopping process...")
        pm.stop_process("test")
        print(f"Process stopped: {not pm.is_running('test')}")
